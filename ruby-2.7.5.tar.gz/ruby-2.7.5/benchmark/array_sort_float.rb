arr = Array.new(1000) { rand }
10000.times { arr.sort }
