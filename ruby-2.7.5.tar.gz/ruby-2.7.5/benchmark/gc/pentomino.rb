require_relative '../app_pentomino'
